# 声劇台本置き場 ふりがな振り分け機

声劇台本置き場の台本(MHT保存ファイル / 貼り付けテキスト)の漢字にふりがなを付けるツールです。
サーバー不要・APIキー不要で、すべてブラウザ内で動きます。

- 読みの推定: kuromoji(`lib/` に辞書同梱)
- AI(常時): WebLLM でブラウザ内のAIが文脈から読みを付与(PC版Chrome/Edge、WebGPU必須。使えない環境では辞書のみで変換)
- 間違った読みは画面の表または「固定読み」で直せます(ブラウザに保存)

## GitHub Pages で公開する
1. このフォルダの中身をGitHubのリポジトリにアップロード(`lib/dict` を含めて約18MB)
2. Settings → Pages → Source を `Deploy from a branch`、Branch を `main` / `(root)` にして Save
3. 数分後に `https://<ユーザー名>.github.io/<リポジトリ名>/` で開けます

## 補足
- AIモデルは初回だけ数GBのダウンロードが必要です(以降はブラウザに保存)。
- WebLLMは `index.html` 内で `https://esm.run/@mlc-ai/web-llm` から読み込みます。安定させたい場合はバージョンを固定してください。
